Jake Morrissey
jmm9683

Submitting jar file for server, jar file for client, ServerMain.java, ClientMain.java, and ClientObersever.java.

This assignment was tested only on localhost but will work on different IPs, however I did not have access to another computer to test it on. I tested this on a MAC.

https://github.com/jmm9683/EE422C-project-7